Bouton d'action VF : angles vifs, libellé en capitales trackées Jost, jamais d'ombre ni d'arrondi.

```jsx
<Button variant="primary" href="#evaluation">Obtenir une évaluation</Button>
<Button variant="ghost" href="#services">Voir les services</Button>
```

- `variant`: `primary` (fond `--ink-strong`, survol `--accent-deep`), `ghost` (filet 1px `--ink`), `link`.
- Dans une section `[data-theme="dark"]`, passer `onDark` : le primaire s'inverse en `--inverse-canvas`/`--inverse-ink` (ne jamais utiliser `--canvas`, qui vaut #000 en foncé).
- Zone tactile minimale 48px — `size="sm"` descend à 44px, réservé à la nav.
