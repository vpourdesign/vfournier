import * as React from 'react';

/** Le lockup VF, livré en SVG vectorisé. Zone de protection = hauteur du V ; lockup complet ≥ 180px de large. */
export interface LogoProps extends React.HTMLAttributes<HTMLImageElement> {
  /** full = pâle · dark = foncé · mono = currentColor · mark = VF + IMMOBILIER seuls */
  variant?: 'full' | 'dark' | 'mono' | 'mark';
  width?: number;
  /** Chemin relatif vers assets/ depuis la page hôte */
  assetsBase?: string;
}
export declare function Logo(props: LogoProps): JSX.Element;
