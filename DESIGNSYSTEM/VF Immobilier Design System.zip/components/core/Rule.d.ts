import * as React from 'react';

/** Le filet — la seule ornementation autorisée du système. */
export interface RuleProps extends React.HTMLAttributes<HTMLElement> {
  /** hairline = 1px --hairline ; accent = 2px --accent (version flanquante du logo) */
  variant?: 'hairline' | 'accent';
  orientation?: 'horizontal' | 'vertical';
  /** Longueur fixe en px ; sinon remplit son conteneur */
  length?: number;
}
export declare function Rule(props: RuleProps): JSX.Element;
