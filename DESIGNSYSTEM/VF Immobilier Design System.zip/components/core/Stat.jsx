import React from 'react';

export function Stat({ value, label, style, ...rest }) {
  return (
    <div style={{ ...style }} {...rest}>
      <div style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'clamp(30px,3.4vw,46px)', lineHeight: 1, color: 'var(--ink-strong)' }}>{value}</div>
      <div style={{ fontFamily: 'var(--ff-label)', fontSize: 'var(--fs-label-sm)', textTransform: 'uppercase', letterSpacing: '.24em', color: 'var(--accent-deep)', marginTop: '12px' }}>{label}</div>
    </div>
  );
}
