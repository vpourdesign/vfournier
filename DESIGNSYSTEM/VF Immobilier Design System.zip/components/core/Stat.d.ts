import * as React from 'react';

/** Preuve chiffrée : nombre Playfair + libellé tracké. Aucun cadre, aucun fond. */
export interface StatProps extends React.HTMLAttributes<HTMLDivElement> {
  value: React.ReactNode;
  label: React.ReactNode;
}
export declare function Stat(props: StatProps): JSX.Element;
