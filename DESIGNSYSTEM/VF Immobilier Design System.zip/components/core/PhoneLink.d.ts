import * as React from 'react';

/** Le numéro est un élément de design, pas une note de bas de page. Toujours cliquable. */
export interface PhoneLinkProps extends React.HTMLAttributes<HTMLAnchorElement> {
  number?: string;
  /** Valeur brute du href tel: */
  tel?: string;
  /** Sur-titre tracké à gauche du numéro ; passer "" pour l'enlever */
  kicker?: string;
  size?: 'md' | 'lg';
}
export declare function PhoneLink(props: PhoneLinkProps): JSX.Element;
