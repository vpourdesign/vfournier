import * as React from 'react';

/** Sur-titre de section : capitale trackée en --accent-deep, précédée d'un filet. Jamais de puce ni de pilule. */
export interface EyebrowProps extends React.HTMLAttributes<HTMLElement> {
  children?: React.ReactNode;
  /** Longueur du filet en px (48 par défaut) */
  ruleLength?: number;
  as?: keyof JSX.IntrinsicElements;
}
export declare function Eyebrow(props: EyebrowProps): JSX.Element;
