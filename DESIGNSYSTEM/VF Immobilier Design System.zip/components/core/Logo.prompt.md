Lockup de marque. Ne jamais redessiner : quatre SVG livrés dans `assets/`.

```jsx
<Logo variant="mark" width={132} assetsBase="../../assets" />
```

`full` (pâle) · `dark` · `mono` (recolorable) · `mark` (en-tête, favicon). Largeur minimale du lockup complet : 180px.
