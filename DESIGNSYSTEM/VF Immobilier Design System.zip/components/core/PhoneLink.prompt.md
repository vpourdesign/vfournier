Numéro de téléphone traité comme un élément de design (Inter 500, échelle display).

```jsx
<PhoneLink kicker="Parlons-en" number="514 816-5798" tel="+15148165798" />
```
