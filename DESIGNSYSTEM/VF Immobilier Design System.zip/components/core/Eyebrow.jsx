import React from 'react';

export function Eyebrow({ children, ruleLength = 48, as: Tag = 'p', style, ...rest }) {
  return (
    <Tag style={{ display: 'flex', alignItems: 'center', gap: '16px', margin: '0 0 28px',
      fontFamily: 'var(--ff-label)', fontSize: 'var(--fs-label)', fontWeight: 400,
      textTransform: 'uppercase', letterSpacing: 'var(--ls-label)', color: 'var(--accent-deep)', ...style }} {...rest}>
      <span aria-hidden="true" style={{ width: ruleLength + 'px', height: '1px', background: 'var(--accent)', flex: 'none' }}></span>
      {children}
    </Tag>
  );
}
