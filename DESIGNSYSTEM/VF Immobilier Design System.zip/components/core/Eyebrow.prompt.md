Sur-titre de section — la seule étiquette du système, toujours flanquée d'un filet.

```jsx
<Eyebrow>Les services</Eyebrow>
```

Interdit : puce, point coloré, pilule, fond. Le filet fait 48px par défaut (`ruleLength`).
