import * as React from 'react';

/**
 * Bouton VF — angles vifs, capitale trackée Jost, aucune ombre.
 */
export interface ButtonProps extends React.HTMLAttributes<HTMLElement> {
  /** primary = aplat encre; ghost = filet 1px; link = souligné discret */
  variant?: 'primary' | 'ghost' | 'link';
  size?: 'sm' | 'md' | 'lg';
  /** Rend un <a> au lieu d'un <button> */
  href?: string;
  disabled?: boolean;
  /** À poser dans un bloc [data-theme="dark"] : inverse le primaire */
  onDark?: boolean;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
