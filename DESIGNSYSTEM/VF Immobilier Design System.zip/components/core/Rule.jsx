import React from 'react';

export function Rule({ variant = 'hairline', orientation = 'horizontal', length, style, ...rest }) {
  const accent = variant === 'accent';
  const thickness = accent ? 'var(--rule-w)' : '1px';
  const color = accent ? 'var(--accent)' : 'var(--hairline)';
  const v = orientation === 'vertical';
  return <span aria-hidden="true" style={{ display: 'block', flex: 'none',
    width: v ? thickness : (length ? length + 'px' : '100%'),
    height: v ? (length ? length + 'px' : 'auto') : thickness,
    alignSelf: v && !length ? 'stretch' : undefined, background: color, ...style }} {...rest}></span>;
}
