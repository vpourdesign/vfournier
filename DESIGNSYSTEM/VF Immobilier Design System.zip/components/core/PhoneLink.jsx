import React from 'react';

export function PhoneLink({ number = '514 816-5798', tel = '+15148165798', kicker = 'Parlons-en', size = 'lg', style, ...rest }) {
  return (
    <a href={'tel:' + tel} style={{ display: 'inline-flex', alignItems: 'baseline', gap: '14px', textDecoration: 'none', color: 'var(--ink-strong)', ...style }} {...rest}>
      {kicker ? <span style={{ fontFamily: 'var(--ff-label)', fontSize: '11.5px', textTransform: 'uppercase', letterSpacing: '.24em', color: 'var(--accent-deep)' }}>{kicker}</span> : null}
      <strong style={{ fontFamily: 'var(--ff-body)', fontWeight: 500, letterSpacing: 'var(--ls-numeric)',
        fontSize: size === 'lg' ? 'clamp(24px,2.6vw,34px)' : '19px' }}>{number}</strong>
    </a>
  );
}
