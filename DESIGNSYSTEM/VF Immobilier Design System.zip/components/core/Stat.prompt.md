Chiffre de preuve. Se pose en rangée de 3 sous un filet horizontal.

```jsx
<Stat value="24 h" label="Délai de réponse" />
```

Pas de cadre, pas de fond, pas d'icône. Les chiffres doivent être vérifiables (aucun superlatif).
