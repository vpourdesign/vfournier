Filet de séparation. 1px `--hairline` par défaut ; `variant="accent"` donne 2px `--accent`, la version flanquante du logo.

```jsx
<Rule />
<Rule variant="accent" length={48} />
<Rule orientation="vertical" />
```
