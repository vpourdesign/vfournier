import React from 'react';

const FILES = {
  full: 'logo-vf.svg',
  dark: 'logo-vf-dark.svg',
  mono: 'logo-vf-mono.svg',
  mark: 'logo-vf-mark.svg'
};

export function Logo({ variant = 'full', width = 210, assetsBase = '../../assets', style, ...rest }) {
  return <img src={assetsBase + '/' + FILES[variant]} alt="Vanessa Fournier inc. — VF Immobilier"
    style={{ width: width + 'px', height: 'auto', display: 'block', ...style }} {...rest} />;
}
