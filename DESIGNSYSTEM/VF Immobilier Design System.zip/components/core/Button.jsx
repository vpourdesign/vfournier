import React, { useState } from 'react';

const base = {
  display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '12px',
  minHeight: '52px', padding: '16px 38px', border: '1px solid transparent',
  fontFamily: 'var(--ff-label)', fontSize: '12.5px', fontWeight: 400,
  textTransform: 'uppercase', letterSpacing: '.2em', textDecoration: 'none',
  borderRadius: 'var(--radius-default)', cursor: 'pointer', background: 'none',
  transition: 'background var(--dur-hover) var(--ease), color var(--dur-hover) var(--ease), border-color var(--dur-hover) var(--ease)'
};

const sizes = {
  sm: { minHeight: '44px', padding: '12px 26px', fontSize: '11.5px' },
  md: {},
  lg: { minHeight: '58px', padding: '20px 46px' }
};

export function Button({ variant = 'primary', size = 'md', href, disabled = false, onDark = false, children, ...rest }) {
  const [hover, setHover] = useState(false);
  let skin;
  if (variant === 'primary') {
    skin = onDark
      ? { background: hover ? 'var(--accent)' : 'var(--inverse-canvas)', color: 'var(--inverse-ink)' }
      : { background: hover ? 'var(--accent-deep)' : 'var(--ink-strong)', color: 'var(--canvas)' };
  } else if (variant === 'ghost') {
    skin = onDark
      ? { borderColor: hover ? 'var(--inverse-canvas)' : 'var(--hairline-strong)', background: hover ? 'var(--inverse-canvas)' : 'transparent', color: hover ? 'var(--inverse-ink)' : 'var(--ink)' }
      : { borderColor: hover ? 'var(--ink-strong)' : 'var(--ink)', background: hover ? 'var(--ink-strong)' : 'transparent', color: hover ? 'var(--canvas)' : 'var(--ink)' };
  } else {
    skin = { padding: '16px 0', color: hover ? 'var(--ink-strong)' : 'var(--ink)', borderBottom: '1px solid ' + (hover ? 'var(--ink-strong)' : 'var(--hairline-strong)') };
  }
  const style = { ...base, ...sizes[size], ...skin, ...(disabled ? { opacity: .38, pointerEvents: 'none' } : null) };
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} style={style} aria-disabled={disabled || undefined} disabled={!href && disabled ? true : undefined}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} {...rest}>{children}</Tag>
  );
}
