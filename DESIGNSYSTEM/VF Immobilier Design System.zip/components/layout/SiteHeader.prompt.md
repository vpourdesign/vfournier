En-tête du site : fond crème à 88% + blur 14px, filet bas qui n'apparaît qu'au défilement.

```jsx
<SiteHeader stuck={scrolled} links={[{href:'#services',label:'Services'}]} cta={{href:'#contact',label:'Me joindre'}} />
```

Le soulignement de nav se déploie de gauche à droite au survol — seule animation d'état du système.
