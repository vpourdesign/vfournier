Pied de page. La bannière Royal LePage Urbain avec sa mention d'agence est une obligation réglementaire — ne jamais la retirer ni la descendre sous 64px de haut.

```jsx
<SiteFooter legal={['© 2026 Vanessa Fournier inc.', 'Courtier immobilier']} />
```

Le rouge du logo ne devient jamais une couleur d'interface.
