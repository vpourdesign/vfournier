import * as React from 'react';

/**
 * Pied de page : lockup VF + bannière Royal LePage obligatoire (≥64px de haut), mentions légales sous un filet.
 */
export interface SiteFooterProps extends React.HTMLAttributes<HTMLElement> {
  assetsBase?: string;
  /** Placeholder en attente du logo Royal LePage Commercial ; passer "" une fois le fichier reçu */
  pendingLabel?: string;
  legal?: React.ReactNode[];
}
export declare function SiteFooter(props: SiteFooterProps): JSX.Element;
