import React, { useState } from 'react';
import { Button } from '../core/Button.jsx';
import { Logo } from '../core/Logo.jsx';

function NavLink({ href, children, onClick }) {
  const [hover, setHover] = useState(false);
  return (
    <a href={href} onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ fontFamily: 'var(--ff-label)', fontSize: '11.5px', textTransform: 'uppercase', letterSpacing: 'var(--ls-label-lg)',
        textDecoration: 'none', color: 'var(--ink)', position: 'relative', padding: '6px 0' }}>
      {children}
      <span aria-hidden="true" style={{ position: 'absolute', left: 0, right: hover ? 0 : '100%', bottom: 0, height: '1px', background: 'var(--accent)', transition: 'right var(--dur) var(--ease)' }}></span>
    </a>
  );
}

export function SiteHeader({ links = [], cta, stuck = false, assetsBase = '../../assets', onNavigate, style, ...rest }) {
  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: '24px', padding: (stuck ? '12px ' : '18px ') + 'var(--gutter)',
      background: 'color-mix(in srgb, var(--canvas) 88%, transparent)', backdropFilter: 'blur(14px)',
      borderBottom: '1px solid ' + (stuck ? 'var(--hairline)' : 'transparent'),
      transition: 'border-color var(--dur) var(--ease), padding var(--dur) var(--ease)', ...style }} {...rest}>
      <a href="#top" aria-label="VF Immobilier — accueil" style={{ display: 'block' }} onClick={onNavigate ? (e) => { e.preventDefault(); onNavigate('#top'); } : undefined}>
        <Logo variant="mark" width={132} assetsBase={assetsBase} />
      </a>
      <nav aria-label="Principale" style={{ display: 'flex', alignItems: 'center', gap: '34px' }}>
        {links.map((l) => <NavLink key={l.href} href={l.href} onClick={onNavigate ? (e) => { e.preventDefault(); onNavigate(l.href); } : undefined}>{l.label}</NavLink>)}
        {cta ? <Button size="sm" href={cta.href} onClick={onNavigate ? (e) => { e.preventDefault(); onNavigate(cta.href); } : undefined}>{cta.label}</Button> : null}
      </nav>
    </header>
  );
}
