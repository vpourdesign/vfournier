import * as React from 'react';

export interface SiteHeaderLink { href: string; label: string }
/**
 * En-tête fixe translucide : marque VF à gauche, nav trackée + CTA à droite.
 */
export interface SiteHeaderProps extends React.HTMLAttributes<HTMLElement> {
  links?: SiteHeaderLink[];
  cta?: { href: string; label: string };
  /** État après 24px de défilement : filet bas visible, padding réduit */
  stuck?: boolean;
  assetsBase?: string;
  onNavigate?: (href: string) => void;
}
export declare function SiteHeader(props: SiteHeaderProps): JSX.Element;
