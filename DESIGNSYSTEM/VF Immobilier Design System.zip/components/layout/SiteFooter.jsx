import React from 'react';
import { Logo } from '../core/Logo.jsx';

export function SiteFooter({ assetsBase = '../../assets', pendingLabel = 'Logo Royal LePage Commercial — en attente du fichier client', legal = [], style, ...rest }) {
  return (
    <footer style={{ borderTop: '1px solid var(--hairline)', padding: 'clamp(48px,6vw,80px) 0', ...style }} {...rest}>
      <div style={{ maxWidth: 'var(--max)', margin: '0 auto', paddingInline: 'var(--gutter)' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '40px' }}>
          <Logo variant="full" width={210} assetsBase={assetsBase} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 'clamp(20px,3vw,36px)' }}>
            <img src={assetsBase + '/rlp-urbain-agence.png'} alt="Royal LePage Urbain — agence immobilière franchisée indépendante et autonome" style={{ height: '86px', width: 'auto' }} />
            <div aria-hidden="true" style={{ width: '1px', alignSelf: 'stretch', background: 'var(--hairline-strong)' }}></div>
            {pendingLabel ? (
              <p style={{ fontFamily: 'var(--ff-label)', fontSize: '10.5px', textTransform: 'uppercase', letterSpacing: '.18em',
                color: 'var(--accent-deep)', border: '1px dashed var(--hairline-strong)', padding: '14px 18px', maxWidth: '190px', lineHeight: 1.6, margin: 0 }}>{pendingLabel}</p>
            ) : null}
          </div>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px 28px', marginTop: '44px', paddingTop: '28px',
          borderTop: '1px solid var(--hairline)', fontSize: '13px', color: 'var(--ink-muted)' }}>
          {legal.map((l, i) => <span key={i}>{l}</span>)}
        </div>
      </div>
    </footer>
  );
}
