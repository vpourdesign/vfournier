Jeu d'icônes du système — trois pictos de secteur seulement, repris tels quels du site.

```jsx
<Icon name="commercial" size={30} />
```

Les mêmes tracés existent en fichiers dans `assets/icons/`. Ajout hors de ce jeu : dessin linéaire 1.25px, aucun aplat, aucune emoji.
