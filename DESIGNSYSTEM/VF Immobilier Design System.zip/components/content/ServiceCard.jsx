import React, { useState } from 'react';
import { Icon } from './Icon.jsx';

export function ServiceCard({ icon, title, children, items = [], style, ...rest }) {
  const [hover, setHover] = useState(false);
  return (
    <article onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ background: hover ? 'var(--canvas)' : 'var(--surface-1)', padding: 'clamp(32px,3.4vw,52px)',
        borderRadius: 'var(--radius-default)', boxShadow: 'none',
        transform: hover ? 'translateY(-4px)' : 'none',
        transition: 'transform var(--dur) var(--ease), background var(--dur) var(--ease)', ...style }} {...rest}>
      {icon ? <div style={{ marginBottom: '28px' }}><Icon name={icon} size={30} /></div> : null}
      <h3 style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'var(--fs-headline)', lineHeight: 1.25, color: 'var(--ink-strong)', margin: '0 0 14px' }}>{title}</h3>
      <p style={{ fontSize: '16px', color: 'var(--ink-muted)', margin: 0 }}>{children}</p>
      {items.length ? (
        <ul style={{ listStyle: 'none', margin: '24px 0 0', padding: 0 }}>
          {items.map((it) => (
            <li key={it} style={{ fontFamily: 'var(--ff-label)', fontSize: 'var(--fs-label)', textTransform: 'uppercase', letterSpacing: 'var(--ls-label-tight)', color: 'var(--ink)', padding: '11px 0', borderTop: '1px solid var(--hairline)' }}>{it}</li>
          ))}
        </ul>
      ) : null}
    </article>
  );
}
