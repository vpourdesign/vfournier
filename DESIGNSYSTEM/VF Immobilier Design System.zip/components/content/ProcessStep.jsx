import React from 'react';

export function ProcessStep({ index, title, children, style, ...rest }) {
  const n = String(index).padStart(2, '0');
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '96px minmax(0,1fr) minmax(0,1.3fr)', gap: 'clamp(16px,3vw,48px)',
      alignItems: 'start', padding: 'clamp(28px,3.4vw,44px) 0', borderBottom: '1px solid var(--hairline)', ...style }} {...rest}>
      <div style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'clamp(26px,2.8vw,38px)', lineHeight: 1, color: 'var(--accent)' }}>{n}</div>
      <h3 style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'var(--fs-headline)', lineHeight: 1.25, color: 'var(--ink-strong)', margin: 0 }}>{title}</h3>
      <p style={{ fontSize: '16px', color: 'var(--ink-muted)', margin: 0 }}>{children}</p>
    </div>
  );
}
