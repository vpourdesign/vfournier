import React from 'react';

const PATHS = {
  commercial: 'M3 21h18M5 21V7l7-4 7 4v14M9 12h2M13 12h2M9 16h2M13 16h2',
  industriel: 'M4 21h18M4 21V9l6-3v15M10 21V6l10 3v12M14 12h2M14 16h2',
  residentiel: 'M3 11l9-7 9 7M5 10v11h14V10M10 21v-6h4v6'
};

export function Icon({ name, size = 30, style, ...rest }) {
  const d = PATHS[name];
  if (!d) return null;
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true" focusable="false"
      style={{ display: 'block', fill: 'none', stroke: 'currentColor', strokeWidth: 1.25, strokeLinecap: 'round', strokeLinejoin: 'round', color: 'var(--accent-deep)', ...style }} {...rest}>
      <path d={d} />
    </svg>
  );
}
