Carte de service. Se pose en grille de 3 avec `gap:1px` sur fond `--hairline` — les filets de la grille FONT les séparateurs.

```jsx
<div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:1,background:'var(--hairline)',border:'1px solid var(--hairline)'}}>
  <ServiceCard icon="commercial" title="Commercial" items={['Analyse de rendement']}>Immeubles à revenus…</ServiceCard>
</div>
```

Jamais d'ombre, jamais d'arrondi.
