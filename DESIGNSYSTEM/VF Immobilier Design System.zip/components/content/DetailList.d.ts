import * as React from 'react';

export interface DetailListItem {
  term: string;
  value: React.ReactNode;
  /** Rend la valeur en lien natif (tel:, mailto:, https:) */
  href?: string;
}
/** Liste de coordonnées : libellé tracké à gauche, valeur alignée à droite, filet entre chaque rangée. */
export interface DetailListProps extends React.HTMLAttributes<HTMLDListElement> {
  items: DetailListItem[];
}
export declare function DetailList(props: DetailListProps): JSX.Element;
