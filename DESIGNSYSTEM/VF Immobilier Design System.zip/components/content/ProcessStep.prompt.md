Rangée d'étape numérotée. Empiler dans un conteneur qui porte `borderTop:1px solid var(--hairline)`.

```jsx
<ProcessStep index={1} title="Rencontre">On clarifie l'objectif, le budget réel et l'échéancier.</ProcessStep>
```
