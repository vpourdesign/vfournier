import * as React from 'react';

/** Les trois pictos de secteur du site VF. Traits 1.25px, jamais de forme pleine. */
export interface IconProps extends React.SVGAttributes<SVGElement> {
  name: 'commercial' | 'industriel' | 'residentiel';
  size?: number;
}
export declare function Icon(props: IconProps): JSX.Element | null;
