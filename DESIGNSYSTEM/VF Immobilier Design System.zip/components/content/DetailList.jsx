import React from 'react';

export function DetailList({ items = [], style, ...rest }) {
  return (
    <dl style={{ margin: 0, borderTop: '1px solid var(--hairline)', ...style }} {...rest}>
      {items.map((it) => (
        <div key={it.term} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: '24px', padding: '22px 0', borderBottom: '1px solid var(--hairline)' }}>
          <dt style={{ fontFamily: 'var(--ff-label)', fontSize: 'var(--fs-label-sm)', textTransform: 'uppercase', letterSpacing: '.24em', color: 'var(--accent-deep)' }}>{it.term}</dt>
          <dd style={{ margin: 0, fontSize: '18px', color: 'var(--ink-strong)', textAlign: 'right' }}>
            {it.href ? <a href={it.href} style={{ textDecoration: 'none', borderBottom: '1px solid var(--hairline-strong)', paddingBottom: '2px' }}>{it.value}</a> : it.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
