import * as React from 'react';

/**
 * Carte de service : fond blanc, angles vifs, aucune ombre. Au survol, translation -4px.
 */
export interface ServiceCardProps extends React.HTMLAttributes<HTMLElement> {
  icon?: 'commercial' | 'industriel' | 'residentiel';
  title: React.ReactNode;
  /** Paragraphe d'introduction */
  children?: React.ReactNode;
  /** Liste de prestations, en capitales trackées séparées par des filets */
  items?: string[];
}
export declare function ServiceCard(props: ServiceCardProps): JSX.Element;
