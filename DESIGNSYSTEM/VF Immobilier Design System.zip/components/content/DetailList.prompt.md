Bloc de coordonnées. Téléphone et courriel doivent toujours être des liens natifs.

```jsx
<DetailList items={[
  { term: 'Téléphone', value: '514 816-5798', href: 'tel:+15148165798' },
  { term: 'Bannière', value: 'Royal LePage Urbain' }
]} />
```
