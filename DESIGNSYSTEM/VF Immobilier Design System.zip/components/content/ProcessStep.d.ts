import * as React from 'react';

/** Une étape du processus : numéro Playfair taupe, titre, description. Rangée séparée par un filet. */
export interface ProcessStepProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Numéro affiché sur 2 chiffres (1 → 01) */
  index: number;
  title: React.ReactNode;
  children?: React.ReactNode;
}
export declare function ProcessStep(props: ProcessStepProps): JSX.Element;
