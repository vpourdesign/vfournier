# VF Immobilier — Design System

Système de design de **Vanessa Fournier inc.**, courtier immobilier chez
**Royal LePage Urbain** (commercial · industriel · résidentiel, Grand Montréal).

Le système est éditorial et volontairement pauvre : un fond crème, une encre gris
chaud, un seul accent taupe, trois familles typographiques, et le filet comme unique
ornementation. Le positionnement à défendre est **conseil**, pas **vente** :
« Une courtière qui vend du commercial et de l'industriel ne se vend pas comme une
courtière résidentielle. »

Signature de marque : **Investir. Acheter. Vendre. Avec stratégie.**

## Sources

| Source | Chemin | Nature |
|---|---|---|
| DESIGN.md v1.0 | `uploads/DESIGN.md` → copie dans `guidelines/DESIGN.source.md` | Source de vérité d'origine (tokens, typo, composants, interdits), extraite de la papeterie VF (carte d'affaires, pancarte résidentielle, pancarte commerciale), avril 2026 |
| Site one-pager | `uploads/index.html` | Site en production, autonome, sans build — vfimmobilier.com |
| README de livraison | `uploads/README.md` | Notes de mise en ligne et reste-à-faire |
| Logos, photos, bannières | `uploads/*.svg`, `*.webp`, `*.png`, `*.jpg` | Copiés tels quels dans `assets/` |

Aucun dépôt Git, aucun fichier Figma n'a été fourni. Le code du one-pager a servi de
source de vérité pour toutes les valeurs numériques (paddings, tailles, tracking) —
rien n'a été arrondi.

---

## Index du dépôt

| Chemin | Contenu |
|---|---|
| `styles.css` | Point d'entrée global — uniquement des `@import` |
| `tokens/` | `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `motion.css`, `base.css` |
| `components/core/` | Button · Eyebrow · Rule · Stat · PhoneLink · Logo |
| `components/content/` | Icon · ServiceCard · ProcessStep · DetailList |
| `components/layout/` | SiteHeader · SiteFooter |
| `ui_kits/site-vitrine/` | Recréation complète de vfimmobilier.com |
| `templates/page-vf/` | Squelette de page prêt à remplir (Page VF) |
| `guidelines/` | Cartes-specimens (Colors, Type, Spacing, Brand) + `DESIGN.source.md` |
| `assets/` | Logos, favicon, portraits détourés, bannières RLP, icônes SVG |
| `SKILL.md` | Enveloppe Agent Skill pour usage hors de ce projet |

### Composants

**Core** — `Button`, `Eyebrow`, `Rule`, `Stat`, `PhoneLink`, `Logo`
**Content** — `Icon`, `ServiceCard`, `ProcessStep`, `DetailList`
**Layout** — `SiteHeader`, `SiteFooter`

Chaque composant a son `.d.ts` (contrat de props) et son `.prompt.md` (quoi/quand,
exemple, variantes).

#### Ajouts assumés

L'inventaire vient de DESIGN.md (`logo`, `eyebrow`, `rule`, `stat`, `card-service`,
`btn`, `phone`) et du code du site. Trois ajouts, chacun présent dans le site mais pas
nommé comme composant dans DESIGN.md :

- **Icon** — enveloppe des trois pictos de secteur déjà tracés dans `index.html`, pour
  éviter que quiconque en redessine.
- **ProcessStep** et **DetailList** — les blocs « processus » et « contact » du site,
  extraits tels quels.
- **SiteHeader** / **SiteFooter** — l'en-tête et le pied de page du site ; le pied de
  page porte une obligation réglementaire (bannière Royal LePage) qu'il ne faut pas
  pouvoir oublier.

Aucun Toast, Modal, Tabs, Avatar : le système n'en a pas, et n'en veut pas.

---

## CONTENT FUNDAMENTALS

**Langue.** Français du Québec (`fr-CA`), sans exception. Espaces insécables devant
`?`, `!`, `:`, `;` et dans les nombres (« 514 816-5798 », « 24 h », « 48 heures »).
Apostrophe typographique (’), guillemets français (« ») quand il en faut.

**Personne.** « Je » pour Vanessa, « vous » pour le client. Jamais « nous » (c'est une
courtière, pas une équipe), jamais la troisième personne (« Vanessa vous accompagne »).
Exemple du site : *« Je travaille les deux marchés… Vous restez décideur. »*

**Ton.** Direct, factuel, un peu sec. Phrases courtes. On énonce une méthode, pas une
promesse. Le contenu doit lire comme un mémo de conseiller, pas comme une brochure.

- ✅ *« Comparables, historique du secteur, contraintes de zonage ou de financement.
  Vous recevez les chiffres, pas une impression. »*
- ✅ *« Sans engagement, et sans discours de vente. »*
- ❌ *« Votre partenaire de confiance pour tous vos projets immobiliers ! »*

**Superlatifs : interdits.** « Le meilleur », « n°1 », « la référence » ne sont pas
utilisables — rien qui ne soit pas vérifiable. Les seuls chiffres affichés sont des
faits (3 secteurs, 2 bannières, 24 h de délai de réponse).

**Casse.** Titres en casse de phrase, jamais en Title Case anglophone
(« Trois marchés, une même méthode. », pas « Trois Marchés »). Les capitales sont
réservées aux libellés trackés (`eyebrow`, nav, listes de prestations) et au lockup nom.
Les titres se terminent par un point — ce sont des phrases.

**Rythme.** Un sur-titre (2–3 mots : « L'approche », « Les services », « Le processus »),
un titre Playfair sur 2–4 lignes coupées à la main avec `<br>`, puis du texte courant
plafonné à 62 caractères de mesure.

**Emoji : jamais.** Aucun emoji, aucune puce décorative, aucun point coloré. Les seuls
caractères non alphabétiques utilisés comme séparateurs sont le point médian (·) dans
« Commercial · Industriel · Résidentiel » et le tiret cadratin (—).

**Appels à l'action.** Verbe à l'infinitif ou impératif, sans point d'exclamation :
« Obtenir une évaluation », « Voir les services », « Me joindre », « Demander mon
évaluation ». Le numéro de téléphone est lui-même un CTA.

**Mentions obligatoires.** « Royal LePage Urbain, agence immobilière — franchisée
indépendante et autonome » doit apparaître au pied de chaque support. Titre
professionnel exact : « courtier immobilier » (le féminin n'est pas utilisé dans le
titre légal).

---

## VISUAL FOUNDATIONS

**Couleur.** Un fond crème `#F7F3EE`, du blanc pour les cartes, une bande calme
`#F0EBE4`, trois niveaux d'encre gris chaud, et **un seul accent** : le taupe
`#A59D95`. Pas plus d'un accent chromatique par écran. Aucun aplat de couleur vive.
Le rouge Royal LePage `#FF0000` n'existe que dans le fichier logo — jamais en bouton,
lien, bordure ou fond. Contrainte de contraste : le taupe pur donne 2.2:1 sur crème,
donc il ne porte que des filets, des icônes et des capitales décoratives ≥16px ; pour
tout texte informatif, `--accent-deep` `#8A8078` (3.4:1) au minimum.

**Thème foncé.** Un override de bloc, `[data-theme="dark"]`, pas un mode global :
la section Évaluation est noire au milieu d'une page crème. `--inverse-canvas` et
`--inverse-ink` ne sont jamais surchargés — c'est ce qui empêche le bouton primaire
de disparaître sur fond noir.

**Typographie.** Trois familles, pas quatre. Playfair Display 400/500 (titres et
monogramme VF), Jost 400 (capitales trackées), Inter 300/400/500 (texte courant,
lockup nom, chiffres). Pas d'italique, pas de gras au-delà de 500. **La hiérarchie
secondaire passe par le tracking, jamais par le poids ni par la couleur** :
`.28em` pour les sur-titres 12px, `.22em` pour les libellés larges, `.12–.14em` pour
le lockup nom. Les titres display ont un tracking négatif (`-.015em`).

**Espacement.** Base 8px, échelle 4 → 176. Rythme vertical unique :
`clamp(88px, 11vw, 176px)` entre sections, sans exception. Gouttière fluide
`clamp(24px, 5vw, 80px)`, conteneur 1280px, mesure de lecture 62ch. Le blanc tournant
est traité comme le composant le plus important du système.

**Fonds.** Aplats unis uniquement. **Aucun dégradé**, aucune texture, aucun motif
répété, aucune illustration. Le seul « fond » différencié est la bande `--surface-2`
de la section Services et le bloc noir de la section Évaluation. Pas d'image en
full-bleed : la seule photo est un portrait détouré posé sur le crème.

**Photographie.** Portraits **détourés**, alpha propre, jamais en cadre ni en médaillon
rond, jamais de filtre ni de vignette. La photo touche le bord bas de sa section —
elle « se tient dans » la page. Ambiance chromatique : neutre chaude, alignée sur le
crème ; ni refroidie, ni saturée, ni grainée, ni noir et blanc.

**Bordures & filets.** Filet 1px `--hairline` `#DCD5CC` pour toute séparation ; filet
flanquant 2px `--accent` pour l'ornement (la marque du logo). Les grilles de cartes
utilisent `gap:1px` sur fond `--hairline` : les gouttières **sont** les séparateurs.
Séparateur vertical `--hairline-strong` `#C4BBB0`.

**Ombres.** Aucune. `box-shadow` n'existe pas dans le système. La profondeur se joue
par le contraste de surface (blanc sur crème) et par le filet.

**Rayons.** `0` partout dans l'UI. Le seul rayon du système, 18px, est celui du coin de
pancarte imprimée et ne doit jamais apparaître à l'écran. Pas de pilule, pas de chip.

**Transparence & flou.** Un seul usage : l'en-tête fixe, `color-mix(in srgb, var(--canvas) 88%, transparent)`
+ `backdrop-filter: blur(14px)`. Nulle part ailleurs.

**Éléments fixes.** L'en-tête est le seul élément fixé. Il n'a pas de filet bas au repos ;
au-delà de 24px de défilement il gagne `border-bottom: 1px var(--hairline)` et son padding
vertical passe de 18px à 12px.

**Animation.** Un easing unique, `cubic-bezier(.22, 1, .36, 1)`. Un seul geste de
révélation : opacité 0→1 + `translateY(24px→0)`, 620–900ms, stagger 90ms, une seule
fois par élément. Survols en 240–280ms. Aucun rebond, aucun ressort, aucun parallaxe.
Tout est coupé sous `prefers-reduced-motion`.

**Survols.** Jamais d'opacité, jamais d'ombre. Bouton primaire : le fond passe de
`--ink-strong` à `--accent-deep`. Bouton fantôme : il se remplit d'encre. Carte de
service : `translateY(-4px)` + le fond passe du blanc au crème. Lien de nav : un filet
taupe 1px se déploie de gauche à droite. Lien de coordonnées : le soulignement passe de
`--hairline-strong` à `--ink-strong`.

**États pressés.** Pas de réduction d'échelle, pas de changement de couleur dédié — le
système n'a pas d'état `:active` distinct. La cible tactile minimale est 48px (44px
toléré pour le CTA de nav).

**Focus.** Contour 2px `--ink-strong`, offset 3px, sur tout élément focusable. Non
négociable — cible WCAG 2.1 AA.

**Cartes.** Fond blanc, angles vifs, aucune ombre, aucune bordure propre : ce sont les
gouttières 1px de la grille qui les délimitent. Padding `clamp(32px, 3.4vw, 52px)`.

**Composition signature.** Texte à gauche sur 6–7 colonnes, image détourée à droite
débordant le bas de la section — c'est la composition de la pancarte, rejouée en hero.
Grille 12 colonnes desktop / 6 tablette / 1 mobile.

---

## ICONOGRAPHY

Le système n'a **pas** de bibliothèque d'icônes. Il a exactement **trois pictos**, tracés
à la main dans le site pour les trois secteurs, copiés ici en fichiers :

- `assets/icons/commercial.svg` — façade d'immeuble à revenus
- `assets/icons/industriel.svg` — entrepôt / production
- `assets/icons/residentiel.svg` — maison

Spécification : viewBox 24×24, `fill: none`, `stroke: currentColor`, **`stroke-width: 1.25`**,
extrémités arrondies, rendus à 30px, couleur `--accent-deep`. **Aucune icône pleine** —
c'est un interdit explicite du système.

Pas de police d'icônes, pas de sprite, aucune dépendance CDN (Lucide, Heroicons ou autre).
Si une icône manque, la dessiner dans la même grammaire — trait 1.25px, aucun aplat — ou
s'en passer : le système préfère le texte à l'icône.

**Emoji : jamais.** **Caractères Unicode comme icônes :** uniquement le point médian (·)
en séparateur et le tiret cadratin (—). Pas de flèches, pas de chevrons décoratifs.

**Logos** — quatre lockups vectorisés (contours, aucune dépendance de police) :

| Fichier | Usage |
|---|---|
| `assets/logo-vf.svg` | Lockup complet, thème pâle — pied de page (≥180px de large) |
| `assets/logo-vf-dark.svg` | Lockup complet, thème foncé |
| `assets/logo-vf-mono.svg` | `currentColor`, recolorable en CSS |
| `assets/logo-vf-mark.svg` | VF + IMMOBILIER seuls — en-tête, favicon |
| `assets/favicon.svg` | Favicon |

Zone de protection = la hauteur du **V**. Ne jamais recomposer le lockup en texte vivant.

**Bannière partenaire** — `assets/rlp-urbain-agence.png` (Royal LePage Urbain + mention
d'agence) et `assets/rlp-urbain.png` (logo seul), détourés. Hauteur ≥64px au pied de page.
Le logo Royal LePage **Commercial** n'a pas été fourni : un placeholder en pointillé tient
sa place dans `SiteFooter` (prop `pendingLabel`).

**Imagerie** — `assets/vanessa-1400.webp` / `vanessa-900.webp` (portrait détouré, alpha
propre) + `vanessa-900.jpg` (fallback composité sur crème) + `og-vf-immobilier.jpg`
(partage social 1200×630). Aucune banque d'images générique dans le système.

---

## Substitutions à valider

- **Polices.** Le site en production auto-héberge Playfair Display, Jost et Inter en
  `woff2` sous `assets/fonts/` ; ces binaires n'ont pas été fournis. `tokens/fonts.css`
  les charge donc depuis **Google Fonts** — mêmes familles, mêmes graisses, rendu
  identique, mais un appel externe que le site évitait volontairement (Loi 25 / RGPD).
  **Envoyer les `.woff2` pour repasser en auto-hébergé.**
- **Animation.** Le site utilise GSAP + ScrollTrigger + Lenis via CDN. Le UI kit rejoue
  le même geste avec un IntersectionObserver et `scroll-behavior: smooth`, sans dépendance.
- **Royal LePage Commercial.** Fichiers logo toujours en attente côté client.
