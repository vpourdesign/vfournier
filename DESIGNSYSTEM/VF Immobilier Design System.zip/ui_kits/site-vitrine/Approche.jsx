const { Eyebrow, Stat } = window.VFImmobilierDesignSystem_97f9cc;

function Approche() {
  return (
    <section id="approche" style={{ paddingBlock: 'var(--section-y)' }}>
      <div style={{ maxWidth: 'var(--max)', margin: '0 auto', paddingInline: 'var(--gutter)', display: 'grid', gridTemplateColumns: 'minmax(0,.9fr) minmax(0,1.1fr)', gap: 'clamp(32px,6vw,96px)' }}>
        <div>
          <Eyebrow>L’approche</Eyebrow>
          <h2 style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'var(--fs-display-lg)', lineHeight: 1.12, letterSpacing: '-.01em', color: 'var(--ink-strong)', margin: 0 }}>
            Une transaction<br />se prépare<br />avant de se signer.
          </h2>
        </div>
        <div>
          <p style={{ fontSize: 19, lineHeight: 1.65, color: 'var(--ink-muted)', margin: '0 0 1.1em' }}>
            Que ce soit un immeuble à revenus, un local industriel ou la maison familiale, la question de départ est la même&nbsp;: qu’est-ce que cette propriété doit accomplir pour vous&nbsp;?
          </p>
          <p style={{ margin: '0 0 1.1em' }}>
            Je travaille les deux marchés — commercial et résidentiel — sous la bannière Royal LePage Urbain. Ça veut dire une lecture des chiffres avant les émotions, une évaluation appuyée sur des comparables réels, et une négociation menée avec un plan plutôt qu’avec de l’espoir.
          </p>
          <p style={{ margin: 0 }}>
            Vous restez décideur. Mon rôle est de vous donner l’information dont vous avez besoin pour décider vite et bien — et de tenir le dossier jusqu’à la signature chez le notaire.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 'clamp(16px,3vw,40px)', marginTop: 56, paddingTop: 40, borderTop: '1px solid var(--hairline)' }}>
            <Stat value="3" label="Secteurs couverts" />
            <Stat value="2" label="Bannières Royal LePage" />
            <Stat value="24 h" label="Délai de réponse" />
          </div>
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { Approche });
