const { Button, PhoneLink } = window.VFImmobilierDesignSystem_97f9cc;

function Hero({ onNavigate }) {
  return (
    <section id="top" style={{ paddingTop: 'clamp(132px,15vw,180px)', paddingBottom: 0, borderBottom: '1px solid var(--hairline)', overflow: 'hidden' }}>
      <div style={{ maxWidth: 'var(--max)', margin: '0 auto', paddingInline: 'var(--gutter)', display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,.86fr)', gap: 'clamp(24px,5vw,64px)', alignItems: 'end' }}>
        <div style={{ paddingBottom: 'clamp(72px,9vw,128px)' }}>
          <h1 style={{ fontFamily: 'var(--ff-body)', fontWeight: 300, textTransform: 'uppercase', fontSize: 'clamp(29px,4.6vw,60px)', lineHeight: 1.05, letterSpacing: '.12em', color: 'var(--ink-strong)', margin: 0 }}>
            Vanessa&nbsp;Fournier<sup style={{ fontSize: '.3em', letterSpacing: '.04em', verticalAlign: 'super', fontWeight: 400, textTransform: 'none' }}>inc.</sup>
          </h1>
          <p style={{ display: 'flex', alignItems: 'center', gap: 18, margin: '26px 0 10px', fontFamily: 'var(--ff-label)', fontWeight: 400, textTransform: 'uppercase', fontSize: 'clamp(14px,1.5vw,19px)', letterSpacing: '.22em', color: 'var(--ink-strong)' }}>
            Courtier immobilier<span style={{ height: 1, background: 'var(--hairline-strong)', flex: 1 }}></span>
          </p>
          <p style={{ fontFamily: 'var(--ff-label)', textTransform: 'uppercase', fontSize: 'clamp(12px,1.25vw,16px)', letterSpacing: '.22em', color: 'var(--accent-deep)', margin: 0 }}>
            Commercial · Industriel · Résidentiel
          </p>
          <p style={{ fontFamily: 'var(--ff-display)', fontSize: 'clamp(38px,5.6vw,84px)', lineHeight: 1.04, letterSpacing: '-.015em', color: 'var(--ink-strong)', margin: 'clamp(40px,5vw,64px) 0 0' }}>
            Investir.<br />Acheter. Vendre.<br /><em style={{ fontStyle: 'normal', color: 'var(--accent-deep)' }}>Avec stratégie.</em>
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, marginTop: 40 }}>
            <Button href="#evaluation" onClick={(e) => { e.preventDefault(); onNavigate('#evaluation'); }}>Obtenir une évaluation</Button>
            <Button variant="ghost" href="#services" onClick={(e) => { e.preventDefault(); onNavigate('#services'); }}>Voir les services</Button>
          </div>
          <div style={{ marginTop: 36 }}><PhoneLink /></div>
        </div>
        <div style={{ alignSelf: 'end', marginBottom: -1 }}>
          <picture>
            <source srcSet="../../assets/vanessa-1400.webp" type="image/webp" media="(min-width:861px)" />
            <source srcSet="../../assets/vanessa-900.webp" type="image/webp" />
            <img src="../../assets/vanessa-900.jpg" alt="Vanessa Fournier, courtier immobilier" style={{ width: '100%', maxWidth: 620, marginLeft: 'auto', display: 'block' }} />
          </picture>
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { Hero });
