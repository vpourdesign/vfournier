const { Eyebrow, Button } = window.VFImmobilierDesignSystem_97f9cc;

function Evaluation() {
  return (
    <section id="evaluation" data-theme="dark" style={{ paddingBlock: 'var(--section-y)', background: 'var(--canvas)', color: 'var(--ink)' }}>
      <div style={{ maxWidth: 'var(--max)', margin: '0 auto', paddingInline: 'var(--gutter)', display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 'clamp(32px,6vw,96px)', alignItems: 'center' }}>
        <div>
          <Eyebrow>Évaluation</Eyebrow>
          <h2 style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'var(--fs-display-lg)', lineHeight: 1.12, letterSpacing: '-.01em', color: 'var(--ink-strong)', margin: 0, maxWidth: '18ch' }}>
            Combien vaut votre propriété aujourd’hui&nbsp;?
          </h2>
        </div>
        <div>
          <p style={{ fontSize: 19, lineHeight: 1.65, color: 'var(--ink-muted)', margin: 0 }}>
            Une évaluation appuyée sur les transactions réelles de votre secteur — commerciales comme résidentielles. Gratuite, sans obligation, livrée sous 48&nbsp;heures.
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, marginTop: 40 }}>
            <Button onDark href="mailto:info@vfimmobilier.com?subject=Demande%20d%27%C3%A9valuation">Demander mon évaluation</Button>
            <Button variant="ghost" onDark href="tel:+15148165798">514 816-5798</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { Evaluation });
