const { Eyebrow, ServiceCard } = window.VFImmobilierDesignSystem_97f9cc;

const SERVICES = [
  { icon: 'commercial', title: 'Commercial', body: 'Immeubles à revenus, locaux d’affaires, terrains à développer. On regarde le rendement, pas seulement le prix affiché.', items: ['Analyse de rendement', 'Immeubles à revenus', 'Location commerciale'] },
  { icon: 'industriel', title: 'Industriel', body: 'Entrepôts, ateliers, espaces de production. Zonage, hauteur libre, accès camion : les détails qui font ou défont un bail.', items: ['Vérification de zonage', 'Entrepôt & production', 'Acquisition d’occupant'] },
  { icon: 'residentiel', title: 'Résidentiel', body: 'Première propriété, revente, plex. Une mise en marché préparée, des visites filtrées, une promesse d’achat solide.', items: ['Mise en marché', 'Achat & revente', 'Plex & multilogements'] }
];

function Services() {
  return (
    <section id="services" style={{ paddingBlock: 'var(--section-y)', background: 'var(--surface-2)' }}>
      <div style={{ maxWidth: 'var(--max)', margin: '0 auto', paddingInline: 'var(--gutter)' }}>
        <Eyebrow>Les services</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'var(--fs-display-lg)', lineHeight: 1.12, letterSpacing: '-.01em', color: 'var(--ink-strong)', margin: 0, maxWidth: 'var(--measure)' }}>
          Trois marchés,<br />une même méthode.
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 1, background: 'var(--hairline)', marginTop: 64, border: '1px solid var(--hairline)' }}>
          {SERVICES.map((s) => (
            <ServiceCard key={s.title} icon={s.icon} title={s.title} items={s.items}>{s.body}</ServiceCard>
          ))}
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { Services });
