const { Eyebrow, DetailList } = window.VFImmobilierDesignSystem_97f9cc;

function Contact() {
  return (
    <section id="contact" style={{ paddingBlock: 'var(--section-y)' }}>
      <div style={{ maxWidth: 'var(--max)', margin: '0 auto', paddingInline: 'var(--gutter)', display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 'clamp(32px,6vw,96px)' }}>
        <div>
          <Eyebrow>Contact</Eyebrow>
          <h2 style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'var(--fs-display-lg)', lineHeight: 1.12, letterSpacing: '-.01em', color: 'var(--ink-strong)', margin: 0 }}>
            Un projet,<br />une question,<br />un chiffre à valider.
          </h2>
          <p style={{ fontSize: 19, lineHeight: 1.65, color: 'var(--ink-muted)', marginTop: 28 }}>
            Le plus simple reste le téléphone. Sinon, écrivez-moi&nbsp;: je réponds à tous les courriels sous 24&nbsp;heures ouvrables.
          </p>
        </div>
        <div>
          <DetailList items={[
            { term: 'Téléphone', value: '514 816-5798', href: 'tel:+15148165798' },
            { term: 'Courriel', value: 'info@vfimmobilier.com', href: 'mailto:info@vfimmobilier.com' },
            { term: 'Site', value: 'vfimmobilier.com', href: 'https://vfimmobilier.com' },
            { term: 'Bannière', value: 'Royal LePage Urbain' }
          ]} />
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { Contact });
