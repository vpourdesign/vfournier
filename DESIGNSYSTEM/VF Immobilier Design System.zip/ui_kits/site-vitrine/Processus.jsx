const { Eyebrow, ProcessStep } = window.VFImmobilierDesignSystem_97f9cc;

const STEPS = [
  ['Rencontre', 'On clarifie l’objectif, le budget réel et l’échéancier. Sans engagement, et sans discours de vente.'],
  ['Analyse', 'Comparables, historique du secteur, contraintes de zonage ou de financement. Vous recevez les chiffres, pas une impression.'],
  ['Stratégie', 'Prix, positionnement, séquence de mise en marché ou d’offre. On décide ensemble avant de bouger.'],
  ['Exécution', 'Visites, négociation, conditions, inspections. Je pilote les échéances jusqu’à la signature chez le notaire.']
];

function Processus() {
  return (
    <section style={{ paddingBlock: 'var(--section-y)' }}>
      <div style={{ maxWidth: 'var(--max)', margin: '0 auto', paddingInline: 'var(--gutter)' }}>
        <Eyebrow>Le processus</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ff-display)', fontWeight: 400, fontSize: 'var(--fs-display-lg)', lineHeight: 1.12, letterSpacing: '-.01em', color: 'var(--ink-strong)', margin: 0, maxWidth: 'var(--measure)' }}>
          Ce à quoi vous<br />pouvez vous attendre.
        </h2>
        <div style={{ marginTop: 64, borderTop: '1px solid var(--hairline)' }}>
          {STEPS.map((s, i) => <ProcessStep key={s[0]} index={i + 1} title={s[0]}>{s[1]}</ProcessStep>)}
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { Processus });
