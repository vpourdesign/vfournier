# UI kit — site vitrine vfimmobilier.com

Recréation fidèle du one-pager livré en août 2026 (`uploads/index.html`), recomposée
à partir des composants du système. Aucune invention : sections, textes, ordre et
espacements sont ceux du site en production.

| Fichier | Surface |
|---|---|
| `index.html` | Page complète assemblée, en-tête collant, ancres animées à la révélation |
| `Hero.jsx` | Lockup nom + titre + revendication + photo détourée débordant le bas |
| `Approche.jsx` | Texte long + trois chiffres de preuve |
| `Services.jsx` | Bande `--surface-2` + grille de trois `ServiceCard` |
| `Processus.jsx` | Quatre étapes numérotées |
| `Evaluation.jsx` | Bande `[data-theme="dark"]` — l'unique bloc foncé du site |
| `Contact.jsx` | Coordonnées en `DetailList` |

Le pied de page vient de `SiteFooter` et conserve le placeholder Royal LePage
Commercial en attente du fichier client.

Écarts assumés par rapport au site en production : GSAP + Lenis sont remplacés par
un IntersectionObserver et `scroll-behavior: smooth` (même geste, sans dépendance CDN).
