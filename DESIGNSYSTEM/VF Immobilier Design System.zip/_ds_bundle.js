/* @ds-bundle: {"format":4,"namespace":"VFImmobilierDesignSystem_97f9cc","components":[{"name":"DetailList","sourcePath":"components/content/DetailList.jsx"},{"name":"Icon","sourcePath":"components/content/Icon.jsx"},{"name":"ProcessStep","sourcePath":"components/content/ProcessStep.jsx"},{"name":"ServiceCard","sourcePath":"components/content/ServiceCard.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"PhoneLink","sourcePath":"components/core/PhoneLink.jsx"},{"name":"Rule","sourcePath":"components/core/Rule.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"SiteFooter","sourcePath":"components/layout/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"components/layout/SiteHeader.jsx"}],"sourceHashes":{"components/content/DetailList.jsx":"f5b697fd3761","components/content/Icon.jsx":"9deeb50e2985","components/content/ProcessStep.jsx":"45eb522b91e0","components/content/ServiceCard.jsx":"e081ce443aad","components/core/Button.jsx":"98b774059f98","components/core/Eyebrow.jsx":"9e9f952d7d0b","components/core/Logo.jsx":"812aced9434b","components/core/PhoneLink.jsx":"a3ac594efd93","components/core/Rule.jsx":"9a91a4097e26","components/core/Stat.jsx":"0553e6de672f","components/layout/SiteFooter.jsx":"40b1d5e1dff5","components/layout/SiteHeader.jsx":"b7adf1a38775","ui_kits/site-vitrine/Approche.jsx":"c9ccae710bc4","ui_kits/site-vitrine/Contact.jsx":"2eafad12e95a","ui_kits/site-vitrine/Evaluation.jsx":"b4b99a551189","ui_kits/site-vitrine/Hero.jsx":"234d895181de","ui_kits/site-vitrine/Processus.jsx":"b72250ad893b","ui_kits/site-vitrine/Services.jsx":"c97bd1646d16"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.VFImmobilierDesignSystem_97f9cc = window.VFImmobilierDesignSystem_97f9cc || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/DetailList.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function DetailList({
  items = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("dl", _extends({
    style: {
      margin: 0,
      borderTop: '1px solid var(--hairline)',
      ...style
    }
  }, rest), items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.term,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      gap: '24px',
      padding: '22px 0',
      borderBottom: '1px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement("dt", {
    style: {
      fontFamily: 'var(--ff-label)',
      fontSize: 'var(--fs-label-sm)',
      textTransform: 'uppercase',
      letterSpacing: '.24em',
      color: 'var(--accent-deep)'
    }
  }, it.term), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: 0,
      fontSize: '18px',
      color: 'var(--ink-strong)',
      textAlign: 'right'
    }
  }, it.href ? /*#__PURE__*/React.createElement("a", {
    href: it.href,
    style: {
      textDecoration: 'none',
      borderBottom: '1px solid var(--hairline-strong)',
      paddingBottom: '2px'
    }
  }, it.value) : it.value))));
}
Object.assign(__ds_scope, { DetailList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/DetailList.jsx", error: String((e && e.message) || e) }); }

// components/content/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PATHS = {
  commercial: 'M3 21h18M5 21V7l7-4 7 4v14M9 12h2M13 12h2M9 16h2M13 16h2',
  industriel: 'M4 21h18M4 21V9l6-3v15M10 21V6l10 3v12M14 12h2M14 16h2',
  residentiel: 'M3 11l9-7 9 7M5 10v11h14V10M10 21v-6h4v6'
};
function Icon({
  name,
  size = 30,
  style,
  ...rest
}) {
  const d = PATHS[name];
  if (!d) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: "0 0 24 24",
    width: size,
    height: size,
    "aria-hidden": "true",
    focusable: "false",
    style: {
      display: 'block',
      fill: 'none',
      stroke: 'currentColor',
      strokeWidth: 1.25,
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
      color: 'var(--accent-deep)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("path", {
    d: d
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Icon.jsx", error: String((e && e.message) || e) }); }

// components/content/ProcessStep.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ProcessStep({
  index,
  title,
  children,
  style,
  ...rest
}) {
  const n = String(index).padStart(2, '0');
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gridTemplateColumns: '96px minmax(0,1fr) minmax(0,1.3fr)',
      gap: 'clamp(16px,3vw,48px)',
      alignItems: 'start',
      padding: 'clamp(28px,3.4vw,44px) 0',
      borderBottom: '1px solid var(--hairline)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'clamp(26px,2.8vw,38px)',
      lineHeight: 1,
      color: 'var(--accent)'
    }
  }, n), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'var(--fs-headline)',
      lineHeight: 1.25,
      color: 'var(--ink-strong)',
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '16px',
      color: 'var(--ink-muted)',
      margin: 0
    }
  }, children));
}
Object.assign(__ds_scope, { ProcessStep });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ProcessStep.jsx", error: String((e && e.message) || e) }); }

// components/content/ServiceCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function ServiceCard({
  icon,
  title,
  children,
  items = [],
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("article", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: hover ? 'var(--canvas)' : 'var(--surface-1)',
      padding: 'clamp(32px,3.4vw,52px)',
      borderRadius: 'var(--radius-default)',
      boxShadow: 'none',
      transform: hover ? 'translateY(-4px)' : 'none',
      transition: 'transform var(--dur) var(--ease), background var(--dur) var(--ease)',
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: '28px'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 30
  })) : null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'var(--fs-headline)',
      lineHeight: 1.25,
      color: 'var(--ink-strong)',
      margin: '0 0 14px'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '16px',
      color: 'var(--ink-muted)',
      margin: 0
    }
  }, children), items.length ? /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: '24px 0 0',
      padding: 0
    }
  }, items.map(it => /*#__PURE__*/React.createElement("li", {
    key: it,
    style: {
      fontFamily: 'var(--ff-label)',
      fontSize: 'var(--fs-label)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-label-tight)',
      color: 'var(--ink)',
      padding: '11px 0',
      borderTop: '1px solid var(--hairline)'
    }
  }, it))) : null);
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
const base = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '12px',
  minHeight: '52px',
  padding: '16px 38px',
  border: '1px solid transparent',
  fontFamily: 'var(--ff-label)',
  fontSize: '12.5px',
  fontWeight: 400,
  textTransform: 'uppercase',
  letterSpacing: '.2em',
  textDecoration: 'none',
  borderRadius: 'var(--radius-default)',
  cursor: 'pointer',
  background: 'none',
  transition: 'background var(--dur-hover) var(--ease), color var(--dur-hover) var(--ease), border-color var(--dur-hover) var(--ease)'
};
const sizes = {
  sm: {
    minHeight: '44px',
    padding: '12px 26px',
    fontSize: '11.5px'
  },
  md: {},
  lg: {
    minHeight: '58px',
    padding: '20px 46px'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  href,
  disabled = false,
  onDark = false,
  children,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  let skin;
  if (variant === 'primary') {
    skin = onDark ? {
      background: hover ? 'var(--accent)' : 'var(--inverse-canvas)',
      color: 'var(--inverse-ink)'
    } : {
      background: hover ? 'var(--accent-deep)' : 'var(--ink-strong)',
      color: 'var(--canvas)'
    };
  } else if (variant === 'ghost') {
    skin = onDark ? {
      borderColor: hover ? 'var(--inverse-canvas)' : 'var(--hairline-strong)',
      background: hover ? 'var(--inverse-canvas)' : 'transparent',
      color: hover ? 'var(--inverse-ink)' : 'var(--ink)'
    } : {
      borderColor: hover ? 'var(--ink-strong)' : 'var(--ink)',
      background: hover ? 'var(--ink-strong)' : 'transparent',
      color: hover ? 'var(--canvas)' : 'var(--ink)'
    };
  } else {
    skin = {
      padding: '16px 0',
      color: hover ? 'var(--ink-strong)' : 'var(--ink)',
      borderBottom: '1px solid ' + (hover ? 'var(--ink-strong)' : 'var(--hairline-strong)')
    };
  }
  const style = {
    ...base,
    ...sizes[size],
    ...skin,
    ...(disabled ? {
      opacity: .38,
      pointerEvents: 'none'
    } : null)
  };
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    style: style,
    "aria-disabled": disabled || undefined,
    disabled: !href && disabled ? true : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Eyebrow({
  children,
  ruleLength = 48,
  as: Tag = 'p',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      margin: '0 0 28px',
      fontFamily: 'var(--ff-label)',
      fontSize: 'var(--fs-label)',
      fontWeight: 400,
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-label)',
      color: 'var(--accent-deep)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: ruleLength + 'px',
      height: '1px',
      background: 'var(--accent)',
      flex: 'none'
    }
  }), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FILES = {
  full: 'logo-vf.svg',
  dark: 'logo-vf-dark.svg',
  mono: 'logo-vf-mono.svg',
  mark: 'logo-vf-mark.svg'
};
function Logo({
  variant = 'full',
  width = 210,
  assetsBase = '../../assets',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("img", _extends({
    src: assetsBase + '/' + FILES[variant],
    alt: "Vanessa Fournier inc. \u2014 VF Immobilier",
    style: {
      width: width + 'px',
      height: 'auto',
      display: 'block',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/PhoneLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PhoneLink({
  number = '514 816-5798',
  tel = '+15148165798',
  kicker = 'Parlons-en',
  size = 'lg',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: 'tel:' + tel,
    style: {
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: '14px',
      textDecoration: 'none',
      color: 'var(--ink-strong)',
      ...style
    }
  }, rest), kicker ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--ff-label)',
      fontSize: '11.5px',
      textTransform: 'uppercase',
      letterSpacing: '.24em',
      color: 'var(--accent-deep)'
    }
  }, kicker) : null, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--ff-body)',
      fontWeight: 500,
      letterSpacing: 'var(--ls-numeric)',
      fontSize: size === 'lg' ? 'clamp(24px,2.6vw,34px)' : '19px'
    }
  }, number));
}
Object.assign(__ds_scope, { PhoneLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/PhoneLink.jsx", error: String((e && e.message) || e) }); }

// components/core/Rule.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Rule({
  variant = 'hairline',
  orientation = 'horizontal',
  length,
  style,
  ...rest
}) {
  const accent = variant === 'accent';
  const thickness = accent ? 'var(--rule-w)' : '1px';
  const color = accent ? 'var(--accent)' : 'var(--hairline)';
  const v = orientation === 'vertical';
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true",
    style: {
      display: 'block',
      flex: 'none',
      width: v ? thickness : length ? length + 'px' : '100%',
      height: v ? length ? length + 'px' : 'auto' : thickness,
      alignSelf: v && !length ? 'stretch' : undefined,
      background: color,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Rule });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Rule.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Stat({
  value,
  label,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'clamp(30px,3.4vw,46px)',
      lineHeight: 1,
      color: 'var(--ink-strong)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ff-label)',
      fontSize: 'var(--fs-label-sm)',
      textTransform: 'uppercase',
      letterSpacing: '.24em',
      color: 'var(--accent-deep)',
      marginTop: '12px'
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/layout/SiteFooter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SiteFooter({
  assetsBase = '../../assets',
  pendingLabel = 'Logo Royal LePage Commercial — en attente du fichier client',
  legal = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("footer", _extends({
    style: {
      borderTop: '1px solid var(--hairline)',
      padding: 'clamp(48px,6vw,80px) 0',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max)',
      margin: '0 auto',
      paddingInline: 'var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '40px'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "full",
    width: 210,
    assetsBase: assetsBase
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'clamp(20px,3vw,36px)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: assetsBase + '/rlp-urbain-agence.png',
    alt: "Royal LePage Urbain \u2014 agence immobili\xE8re franchis\xE9e ind\xE9pendante et autonome",
    style: {
      height: '86px',
      width: 'auto'
    }
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      width: '1px',
      alignSelf: 'stretch',
      background: 'var(--hairline-strong)'
    }
  }), pendingLabel ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--ff-label)',
      fontSize: '10.5px',
      textTransform: 'uppercase',
      letterSpacing: '.18em',
      color: 'var(--accent-deep)',
      border: '1px dashed var(--hairline-strong)',
      padding: '14px 18px',
      maxWidth: '190px',
      lineHeight: 1.6,
      margin: 0
    }
  }, pendingLabel) : null)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px 28px',
      marginTop: '44px',
      paddingTop: '28px',
      borderTop: '1px solid var(--hairline)',
      fontSize: '13px',
      color: 'var(--ink-muted)'
    }
  }, legal.map((l, i) => /*#__PURE__*/React.createElement("span", {
    key: i
  }, l)))));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// components/layout/SiteHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function NavLink({
  href,
  children,
  onClick
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      fontFamily: 'var(--ff-label)',
      fontSize: '11.5px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-label-lg)',
      textDecoration: 'none',
      color: 'var(--ink)',
      position: 'relative',
      padding: '6px 0'
    }
  }, children, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 0,
      right: hover ? 0 : '100%',
      bottom: 0,
      height: '1px',
      background: 'var(--accent)',
      transition: 'right var(--dur) var(--ease)'
    }
  }));
}
function SiteHeader({
  links = [],
  cta,
  stuck = false,
  assetsBase = '../../assets',
  onNavigate,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '24px',
      padding: (stuck ? '12px ' : '18px ') + 'var(--gutter)',
      background: 'color-mix(in srgb, var(--canvas) 88%, transparent)',
      backdropFilter: 'blur(14px)',
      borderBottom: '1px solid ' + (stuck ? 'var(--hairline)' : 'transparent'),
      transition: 'border-color var(--dur) var(--ease), padding var(--dur) var(--ease)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("a", {
    href: "#top",
    "aria-label": "VF Immobilier \u2014 accueil",
    style: {
      display: 'block'
    },
    onClick: onNavigate ? e => {
      e.preventDefault();
      onNavigate('#top');
    } : undefined
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "mark",
    width: 132,
    assetsBase: assetsBase
  })), /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Principale",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '34px'
    }
  }, links.map(l => /*#__PURE__*/React.createElement(NavLink, {
    key: l.href,
    href: l.href,
    onClick: onNavigate ? e => {
      e.preventDefault();
      onNavigate(l.href);
    } : undefined
  }, l.label)), cta ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    href: cta.href,
    onClick: onNavigate ? e => {
      e.preventDefault();
      onNavigate(cta.href);
    } : undefined
  }, cta.label) : null));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-vitrine/Approche.jsx
try { (() => {
const {
  Eyebrow,
  Stat
} = window.VFImmobilierDesignSystem_97f9cc;
function Approche() {
  return /*#__PURE__*/React.createElement("section", {
    id: "approche",
    style: {
      paddingBlock: 'var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max)',
      margin: '0 auto',
      paddingInline: 'var(--gutter)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,.9fr) minmax(0,1.1fr)',
      gap: 'clamp(32px,6vw,96px)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "L\u2019approche"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'var(--fs-display-lg)',
      lineHeight: 1.12,
      letterSpacing: '-.01em',
      color: 'var(--ink-strong)',
      margin: 0
    }
  }, "Une transaction", /*#__PURE__*/React.createElement("br", null), "se pr\xE9pare", /*#__PURE__*/React.createElement("br", null), "avant de se signer.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      lineHeight: 1.65,
      color: 'var(--ink-muted)',
      margin: '0 0 1.1em'
    }
  }, "Que ce soit un immeuble \xE0 revenus, un local industriel ou la maison familiale, la question de d\xE9part est la m\xEAme\xA0: qu\u2019est-ce que cette propri\xE9t\xE9 doit accomplir pour vous\xA0?"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 1.1em'
    }
  }, "Je travaille les deux march\xE9s \u2014 commercial et r\xE9sidentiel \u2014 sous la banni\xE8re Royal LePage Urbain. \xC7a veut dire une lecture des chiffres avant les \xE9motions, une \xE9valuation appuy\xE9e sur des comparables r\xE9els, et une n\xE9gociation men\xE9e avec un plan plut\xF4t qu\u2019avec de l\u2019espoir."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Vous restez d\xE9cideur. Mon r\xF4le est de vous donner l\u2019information dont vous avez besoin pour d\xE9cider vite et bien \u2014 et de tenir le dossier jusqu\u2019\xE0 la signature chez le notaire."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'clamp(16px,3vw,40px)',
      marginTop: 56,
      paddingTop: 40,
      borderTop: '1px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "3",
    label: "Secteurs couverts"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "2",
    label: "Banni\xE8res Royal LePage"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "24 h",
    label: "D\xE9lai de r\xE9ponse"
  })))));
}
Object.assign(window, {
  Approche
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-vitrine/Approche.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-vitrine/Contact.jsx
try { (() => {
const {
  Eyebrow,
  DetailList
} = window.VFImmobilierDesignSystem_97f9cc;
function Contact() {
  return /*#__PURE__*/React.createElement("section", {
    id: "contact",
    style: {
      paddingBlock: 'var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max)',
      margin: '0 auto',
      paddingInline: 'var(--gutter)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 'clamp(32px,6vw,96px)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Contact"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'var(--fs-display-lg)',
      lineHeight: 1.12,
      letterSpacing: '-.01em',
      color: 'var(--ink-strong)',
      margin: 0
    }
  }, "Un projet,", /*#__PURE__*/React.createElement("br", null), "une question,", /*#__PURE__*/React.createElement("br", null), "un chiffre \xE0 valider."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      lineHeight: 1.65,
      color: 'var(--ink-muted)',
      marginTop: 28
    }
  }, "Le plus simple reste le t\xE9l\xE9phone. Sinon, \xE9crivez-moi\xA0: je r\xE9ponds \xE0 tous les courriels sous 24\xA0heures ouvrables.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(DetailList, {
    items: [{
      term: 'Téléphone',
      value: '514 816-5798',
      href: 'tel:+15148165798'
    }, {
      term: 'Courriel',
      value: 'info@vfimmobilier.com',
      href: 'mailto:info@vfimmobilier.com'
    }, {
      term: 'Site',
      value: 'vfimmobilier.com',
      href: 'https://vfimmobilier.com'
    }, {
      term: 'Bannière',
      value: 'Royal LePage Urbain'
    }]
  }))));
}
Object.assign(window, {
  Contact
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-vitrine/Contact.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-vitrine/Evaluation.jsx
try { (() => {
const {
  Eyebrow,
  Button
} = window.VFImmobilierDesignSystem_97f9cc;
function Evaluation() {
  return /*#__PURE__*/React.createElement("section", {
    id: "evaluation",
    "data-theme": "dark",
    style: {
      paddingBlock: 'var(--section-y)',
      background: 'var(--canvas)',
      color: 'var(--ink)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max)',
      margin: '0 auto',
      paddingInline: 'var(--gutter)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 'clamp(32px,6vw,96px)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "\xC9valuation"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'var(--fs-display-lg)',
      lineHeight: 1.12,
      letterSpacing: '-.01em',
      color: 'var(--ink-strong)',
      margin: 0,
      maxWidth: '18ch'
    }
  }, "Combien vaut votre propri\xE9t\xE9 aujourd\u2019hui\xA0?")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      lineHeight: 1.65,
      color: 'var(--ink-muted)',
      margin: 0
    }
  }, "Une \xE9valuation appuy\xE9e sur les transactions r\xE9elles de votre secteur \u2014 commerciales comme r\xE9sidentielles. Gratuite, sans obligation, livr\xE9e sous 48\xA0heures."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 14,
      marginTop: 40
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onDark: true,
    href: "mailto:info@vfimmobilier.com?subject=Demande%20d%27%C3%A9valuation"
  }, "Demander mon \xE9valuation"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onDark: true,
    href: "tel:+15148165798"
  }, "514 816-5798")))));
}
Object.assign(window, {
  Evaluation
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-vitrine/Evaluation.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-vitrine/Hero.jsx
try { (() => {
const {
  Button,
  PhoneLink
} = window.VFImmobilierDesignSystem_97f9cc;
function Hero({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    style: {
      paddingTop: 'clamp(132px,15vw,180px)',
      paddingBottom: 0,
      borderBottom: '1px solid var(--hairline)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max)',
      margin: '0 auto',
      paddingInline: 'var(--gutter)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,.86fr)',
      gap: 'clamp(24px,5vw,64px)',
      alignItems: 'end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 'clamp(72px,9vw,128px)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--ff-body)',
      fontWeight: 300,
      textTransform: 'uppercase',
      fontSize: 'clamp(29px,4.6vw,60px)',
      lineHeight: 1.05,
      letterSpacing: '.12em',
      color: 'var(--ink-strong)',
      margin: 0
    }
  }, "Vanessa\xA0Fournier", /*#__PURE__*/React.createElement("sup", {
    style: {
      fontSize: '.3em',
      letterSpacing: '.04em',
      verticalAlign: 'super',
      fontWeight: 400,
      textTransform: 'none'
    }
  }, "inc.")), /*#__PURE__*/React.createElement("p", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 18,
      margin: '26px 0 10px',
      fontFamily: 'var(--ff-label)',
      fontWeight: 400,
      textTransform: 'uppercase',
      fontSize: 'clamp(14px,1.5vw,19px)',
      letterSpacing: '.22em',
      color: 'var(--ink-strong)'
    }
  }, "Courtier immobilier", /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      background: 'var(--hairline-strong)',
      flex: 1
    }
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--ff-label)',
      textTransform: 'uppercase',
      fontSize: 'clamp(12px,1.25vw,16px)',
      letterSpacing: '.22em',
      color: 'var(--accent-deep)',
      margin: 0
    }
  }, "Commercial \xB7 Industriel \xB7 R\xE9sidentiel"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontSize: 'clamp(38px,5.6vw,84px)',
      lineHeight: 1.04,
      letterSpacing: '-.015em',
      color: 'var(--ink-strong)',
      margin: 'clamp(40px,5vw,64px) 0 0'
    }
  }, "Investir.", /*#__PURE__*/React.createElement("br", null), "Acheter. Vendre.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: 'normal',
      color: 'var(--accent-deep)'
    }
  }, "Avec strat\xE9gie.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 14,
      marginTop: 40
    }
  }, /*#__PURE__*/React.createElement(Button, {
    href: "#evaluation",
    onClick: e => {
      e.preventDefault();
      onNavigate('#evaluation');
    }
  }, "Obtenir une \xE9valuation"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    href: "#services",
    onClick: e => {
      e.preventDefault();
      onNavigate('#services');
    }
  }, "Voir les services")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 36
    }
  }, /*#__PURE__*/React.createElement(PhoneLink, null))), /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: 'end',
      marginBottom: -1
    }
  }, /*#__PURE__*/React.createElement("picture", null, /*#__PURE__*/React.createElement("source", {
    srcSet: "../../assets/vanessa-1400.webp",
    type: "image/webp",
    media: "(min-width:861px)"
  }), /*#__PURE__*/React.createElement("source", {
    srcSet: "../../assets/vanessa-900.webp",
    type: "image/webp"
  }), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/vanessa-900.jpg",
    alt: "Vanessa Fournier, courtier immobilier",
    style: {
      width: '100%',
      maxWidth: 620,
      marginLeft: 'auto',
      display: 'block'
    }
  })))));
}
Object.assign(window, {
  Hero
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-vitrine/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-vitrine/Processus.jsx
try { (() => {
const {
  Eyebrow,
  ProcessStep
} = window.VFImmobilierDesignSystem_97f9cc;
const STEPS = [['Rencontre', 'On clarifie l’objectif, le budget réel et l’échéancier. Sans engagement, et sans discours de vente.'], ['Analyse', 'Comparables, historique du secteur, contraintes de zonage ou de financement. Vous recevez les chiffres, pas une impression.'], ['Stratégie', 'Prix, positionnement, séquence de mise en marché ou d’offre. On décide ensemble avant de bouger.'], ['Exécution', 'Visites, négociation, conditions, inspections. Je pilote les échéances jusqu’à la signature chez le notaire.']];
function Processus() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      paddingBlock: 'var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max)',
      margin: '0 auto',
      paddingInline: 'var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Le processus"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'var(--fs-display-lg)',
      lineHeight: 1.12,
      letterSpacing: '-.01em',
      color: 'var(--ink-strong)',
      margin: 0,
      maxWidth: 'var(--measure)'
    }
  }, "Ce \xE0 quoi vous", /*#__PURE__*/React.createElement("br", null), "pouvez vous attendre."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 64,
      borderTop: '1px solid var(--hairline)'
    }
  }, STEPS.map((s, i) => /*#__PURE__*/React.createElement(ProcessStep, {
    key: s[0],
    index: i + 1,
    title: s[0]
  }, s[1])))));
}
Object.assign(window, {
  Processus
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-vitrine/Processus.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-vitrine/Services.jsx
try { (() => {
const {
  Eyebrow,
  ServiceCard
} = window.VFImmobilierDesignSystem_97f9cc;
const SERVICES = [{
  icon: 'commercial',
  title: 'Commercial',
  body: 'Immeubles à revenus, locaux d’affaires, terrains à développer. On regarde le rendement, pas seulement le prix affiché.',
  items: ['Analyse de rendement', 'Immeubles à revenus', 'Location commerciale']
}, {
  icon: 'industriel',
  title: 'Industriel',
  body: 'Entrepôts, ateliers, espaces de production. Zonage, hauteur libre, accès camion : les détails qui font ou défont un bail.',
  items: ['Vérification de zonage', 'Entrepôt & production', 'Acquisition d’occupant']
}, {
  icon: 'residentiel',
  title: 'Résidentiel',
  body: 'Première propriété, revente, plex. Une mise en marché préparée, des visites filtrées, une promesse d’achat solide.',
  items: ['Mise en marché', 'Achat & revente', 'Plex & multilogements']
}];
function Services() {
  return /*#__PURE__*/React.createElement("section", {
    id: "services",
    style: {
      paddingBlock: 'var(--section-y)',
      background: 'var(--surface-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max)',
      margin: '0 auto',
      paddingInline: 'var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Les services"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--ff-display)',
      fontWeight: 400,
      fontSize: 'var(--fs-display-lg)',
      lineHeight: 1.12,
      letterSpacing: '-.01em',
      color: 'var(--ink-strong)',
      margin: 0,
      maxWidth: 'var(--measure)'
    }
  }, "Trois march\xE9s,", /*#__PURE__*/React.createElement("br", null), "une m\xEAme m\xE9thode."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 1,
      background: 'var(--hairline)',
      marginTop: 64,
      border: '1px solid var(--hairline)'
    }
  }, SERVICES.map(s => /*#__PURE__*/React.createElement(ServiceCard, {
    key: s.title,
    icon: s.icon,
    title: s.title,
    items: s.items
  }, s.body)))));
}
Object.assign(window, {
  Services
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-vitrine/Services.jsx", error: String((e && e.message) || e) }); }

__ds_ns.DetailList = __ds_scope.DetailList;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.ProcessStep = __ds_scope.ProcessStep;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.PhoneLink = __ds_scope.PhoneLink;

__ds_ns.Rule = __ds_scope.Rule;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

})();
